<?php
class MY_Model extends CI_Model {

        
}