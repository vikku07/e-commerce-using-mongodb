<html>
        <head>
                <title><?php if($title){
                      echo $title;
                } else {
                    echo "Administration";
                } ?></title>
                <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/assets/css/bootstrap.css">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

                <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/jquery.js"></script>
                <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/popper.js"></script>
                <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/bootstrap.js"></script>
                <script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
                
                <script>
$(document).ready(function(){
    $("#delete").click(function(){
        alert("Are You Sure ?.");
    });
});
</script>
        </head>
        <body>

                
                <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <a class="navbar-brand" href="#">Dashboard</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarColor01">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url('index.php/admin'); ?>">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url(); ?>index.php/admin/category">Manage Category</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url(); ?>index.php/admin/product">Manage Product</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url(); ?>index.php/admin/brand">Manage brand</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url(); ?>index.php/admin/order">Manage order</a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url(); ?>index.php/admin/logout">Log Out</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="text" placeholder="Search">
      <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>
            <div class="container">
                <br>
  <div class="row">
    <div class="col-md-3">
        <div class="card  bg-primary mb-3" style="max-width: 20rem;">
        <div class="card">
            <div class="card-header">Total Orders</div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6"><h1><i class="fa fa-arrow-circle-down"></i></h1></div>
                    <div class="col-md-6">
                <?php 
                $c=$this->mongo_db->count('orders');
                echo "<h1>".$c."</h1>";
                ?>
                    </div>
            </div>
            </div>
            <div class="card-footer">
                <a href="<?php echo base_url('index.php/admin/order'); ?>" data-toggle="tooltip" title="View" class="btn btn-primary"><i class="fa fa-eye"></i></a>
                <a href="<?php echo base_url('index.php/admin/addnewvendor'); ?>" data-toggle="tooltip" title="Add New" class="btn btn-info"><i class="fa fa-edit"></i></a>
                <a href="<?php echo base_url('index.php/admin/ExcelReport') ?>?c=orders" data-toggle="tooltip" title="Download SpreadSheet" class="btn btn-success"><i class="fa fa-download"></i></a>
            </div>
        </div>
    </div>
    </div>
    <div class="col-md-3">
        <div class="card  bg-primary mb-3" style="max-width: 20rem;">
        <div class="card">
             <div class="card-header">Total Products</div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6"><h1><i class="fa fa-arrow-circle-up"></i></h1></div>
                    <div class="col-md-6">
                <?php 
                $c=$this->mongo_db->count('product');
                echo "<h1>".$c."</h1>";
                ?>
                    </div>
            </div>
            </div>
            <div class="card-footer">
                <a href="<?php echo base_url('index.php/admin/displayproducts'); ?>" data-toggle="tooltip" title="View" class="btn btn-primary"><i class="fa fa-eye"></i></a>
                <a href="<?php echo base_url('index.php/admin/product'); ?>" data-toggle="tooltip" title="Add New" class="btn btn-info"><i class="fa fa-edit"></i></a>
                <a href="<?php echo base_url('index.php/admin/ExcelReport') ?>?c=product" data-toggle="tooltip" title="Download SpreadSheet" class="btn btn-success"><i class="fa fa-download"></i></a>
            </div>
        </div>
    </div>
    </div>
    <div class="col-md-3">
        <div class="card  bg-primary mb-3" style="max-width: 20rem;">
        <div class="card">
             <div class="card-header">Total Vendors</div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6"><h1><i class="fa fa-user-plus"></i></h1></div>
                    <div class="col-md-6">
                <?php 
                $c=$this->mongo_db->count('admin');
                echo "<h1>".$c."</h1>";
                ?>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <a href="#" data-toggle="tooltip" title="View" class="btn btn-primary"><i class="fa fa-eye"></i></a>
                <a href="<?php echo base_url('index.php/admin/vendor'); ?>" data-toggle="tooltip" title="Add New" class="btn btn-info"><i class="fa fa-edit"></i></a>
                <a href="<?php echo base_url('index.php/admin/ExcelReport') ?>?c=admin" data-toggle="tooltip" title="Download SpreadSheet" class="btn btn-success"><i class="fa fa-download"></i></a>
            </div>
        </div>
    </div>
    </div>
    <div class="col-md-3">
        <div class="card  bg-primary mb-3" style="max-width: 20rem;">
        <div class="card">
            <div class="card-header">Total Customers</div>
            <div class="card-body">
                 
                <div class="row">
                    <div class="col-md-6"><h1><i class="fa fa-users"></i></h1></div>
                    <div class="col-md-6">
                <?php 
                $c=$this->mongo_db->count('users');
                echo "<h1>".$c."</h1>";
                ?>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <a href="#" data-toggle="tooltip" title="View" class="btn btn-primary"><i class="fa fa-eye"></i></a>
                <a href="<?php echo base_url('index.php/admin/addnewvendor'); ?>" data-toggle="tooltip" title="Add New" class="btn btn-info"><i class="fa fa-edit"></i></a>
                <a href="<?php echo base_url('index.php/admin/ExcelReport') ?>?c=users" data-toggle="tooltip" title="Download SpreadSheet" class="btn btn-success"><i class="fa fa-download"></i></a>
            </div>
        </div>
    </div>
    </div>
    
</div>