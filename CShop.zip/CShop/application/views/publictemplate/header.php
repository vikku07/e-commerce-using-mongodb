<?php $searchdata=$this->mongo_db->select(array('p_name'))->get('product');

 foreach($searchdata as $s){
     $sd[]=$s['p_name'];
 }
 
 
?>

<html>
        <head>
                <title><?php if($title){
                      echo $title;
                } else {
                    echo "Home";
                } ?></title>
                <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/assets/css/bootstrap.css">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
                 <link rel="stylesheet" href="/resources/demos/style.css">
                <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/jquery.js"></script>
                <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/popper.js"></script>
                <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/bootstrap.js"></script>
                <script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
                <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
                <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
                <script>
  $( function() {
    var availableTags =<?php echo json_encode($sd); ?>;
    $( "#tags" ).autocomplete({
      source: availableTags
    });
  } );
  </script>
        </head>
        <body data-spy="scroll" data-target="#myScrollspy" data-offset="1">

                
                <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
  <a class="navbar-brand" href="#"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarColor01">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url(); ?>">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url(); ?>index.php/shop/productbygender?c=Men">Men</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url(); ?>index.php/shop/productbygender?c=Women">Women</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url(); ?>index.php/shop/productbygender?c=Kids">Kids</a>
      </li>
   
      
      
      <li class="nav-item">
        
      </li>
    </ul>
      <ul class="nav justify-content-end">
          <li class="nav-item ">
        <?php if($this->session->userdata('user_id')): ?>
          <div class="dropdown">
  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
   <?php echo $this->session->userdata('username'); ?>
  </button>
  <div class="dropdown-menu">
      <a class="dropdown-item" href="<?php echo base_url('index.php/user/profile'); ?>"><i class="fa fa-bell-o"></i> Notification <span class="badge badge-success">0</span></a>
    <a class="dropdown-item" href="<?php echo base_url('index.php/user/profile'); ?>"><i class="fa fa-user-circle-o"></i> My Profile</a>
    <a class="dropdown-item" href="<?php echo base_url('index.php/user/profile'); ?>"><i class="fa fa-envelope-open-o"></i> My Orders <span class="badge badge-success">0</span></a>
    <a class="dropdown-item" href="<?php echo base_url('index.php/user/logout'); ?>"><i class="fa fa-sign-out"></i> Log Out</a>
  </div>
</div>
          <?php else: ?>
          <a class="nav-link fa fa-sign-in btn btn-dark" href="<?php echo base_url('index.php/user/register'); ?>">Login/Signup</a>
          <?php endif; ?>
      </li>
      <li class="nav-item">
          <p> </p>
      </li>
          <li class="nav-item" >
              <a class="nav-link fa fa-cart-plus btn btn-warning" href="<?php echo base_url('index.php/shoppingcart'); ?>">
               <?php echo $this->cart->total_items(); ?>
          </a>
      </li>
          
      </ul>
      
      
  </div>
</nav>
            <div class="ui-widget">
          
        </div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <div class="container">
                <center>
                    <form  action="<?php echo base_url('index.php/shop/search') ?>" method="post">
        
      <input id="tags" name="search" class="form-control col-sm-6" type="text" placeholder="Search">
     
      
    </form>
                </center>
                <br>
                <?php if(isset($recm)): ?>
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header"><i class="fa fa-support"></i> Recommended For You</div>
                        <div class="card-body">
                            <div class="row">
                                <?php foreach($recm as $rec): ?>
                                 <?php
    
    $discount= round((($rec['price']['marked']-$rec['price']['selling'])/$rec['price']['marked'])*100,0);
    
    ?>
                                <div class="col-sm-3">
                                <div class="card" >
        <img class="card-img-top" src="<?php echo base_url(); ?>assets/catlog_media/<?php echo $rec['images']['0'];  ?>" height="100" width="50"/>
  <div class="card-body">
      <h6 class="card-title"><a href="<?php echo base_url('index.php/shop/product'); ?>/<?php echo $rec['_id'] ?>" ><?php echo $rec['p_name']; ?></a> </h6>
      <p class="card-text"><h6> <i class="fa fa-rupee"></i> <?php echo $rec['price']['selling'] ?></h6><p class="card-text" align="right"><span class="badge badge-danger"><?php echo $discount ?>% off</span><br><i class="fa fa-rupee"></i><del><?php echo $rec['price']['marked'] ?></del></p></p>
  
    
    
    

    
  </div>
                            </div>
                        </div>
                                <?php endforeach; ?>
                    </div>
                </div>
                    </div>
                </div>
                <?php else: ?>
                <br>
                <?php endif; ?>
                <br>
               