
<div class="jumbotron" >
    <h1 class="text-primary"><i class="fa fa-check-square"></i> Verify</h1>
</div>
<div class="row">
                <div class="col-md-2"></div>  
                <div class="col-md-8">
                	  <form action="<?php echo $details['action']; ?>/_payment" method="post" id="payuForm" name="payuForm">
                        <input type="hidden" name="key" value="<?php echo $details['mkey'] ?>" />
                        <input type="hidden" name="hash" value="<?php echo $details['hash'] ?>"/>
                        <input type="hidden" name="txnid" value="<?php echo $details['tid'] ?>" />
                        <input type="hidden" name="p_id" value="<?php echo $details['p_id']; ?>" />
                       
                    <input type="hidden" name="p_qty" value="<?php echo $details['qty']; ?>" />
                        <div class="form-group">
                            <label class="control-label">Total Payable Amount</label>
                            <input class="form-control" name="amount" value="<?php echo $details['amount'] ?>"  readonly/>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Your Name</label>
                            <input class="form-control" name="firstname" id="firstname" value="<?php echo $details['name'] ?>" readonly/>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Email</label>
                            <input class="form-control" name="email" id="email" value="<?php echo $details['mailid'] ?>" readonly/>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Phone</label>
                            <input class="form-control" name="phone" value="<?php echo $details['phoneno'] ?>" readonly />
                        </div>
                        <div class="form-group">
                            <label class="control-label">Product</label>
                            <textarea class="form-control" name="productinfo" readonly><?php echo $details['pinfo'] ?></textarea>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Address</label>
                            <input class="form-control" name="address1" value="<?php echo $details['address'] ?>" readonly/>     
                        </div>
                        <div class="form-group">
                            <input name="surl" value="<?php echo $details['sucess'] ?>" size="64" type="hidden" />
                            <input name="furl" value="<?php echo $details['failure'] ?>" size="64" type="hidden" />                             
                            <input type="hidden" name="service_provider" value="" size="64" /> 
                            <input name="curl" value="<?php echo $details['cancel'] ?> " type="hidden" />
                        </div>
                        <div class="form-group text-center">
                        <input type="submit" value="Pay Now" class="btn btn-success" /></td>
                        </div>
                    </form>                                  
                </div>
                <div class="col-md-2"></div>
            </div>