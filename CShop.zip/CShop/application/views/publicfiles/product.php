
<?php if($this->session->flashdata('err')): ?>
<script type="text/javascript">
    alert("Item is not available in desired quantity ");
</script>
<?php endif; ?>
<div class="row">
    
    <div class="col-5">
        <div class="card">
  <div class="card-body">
      
      
      
      <div id="demo" class="carousel slide" data-ride="carousel">

  <!-- Indicators -->
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <?php for($i=1;$i<count($details['images']);$i++): ?>
    <li data-target="#demo" data-slide-to="<?php echo $i ?>"></li>
    <?php endfor;?>
  </ul>
  
  <!-- The slideshow -->
  <div class="carousel-inner">
    <div class="carousel-item active">
     <img src="<?php echo base_url(); ?>assets/catlog_media/<?php echo $details['images']['0'];  ?>" height="400" width="100%"/>
    </div>
    <?php for($j=1;$j<count($details['images']);$j++): ?>
    <div class="carousel-item">
      <img src="<?php echo base_url(); ?>assets/catlog_media/<?php echo $details['images'][$j];  ?>" height="400" width="100%"/>
    </div>
       <?php endfor;?>
  </div>
  
  <!-- Left and right controls -->
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
      
      
      
      
      
      
      
  
    </div>
        </div>
    </div>
    
    <div class="col-7">
        <div class="card">
  <div class="card-body">
      <h4 class="card-title"><?php echo $details['p_name']; ?></h4>
      <h5><i class="fa fa-rupee"></i> <?php echo $details['price']['selling']; ?> </h5>
      <?php if($details['stock']<5):  ?>
      <p class="text-warning">Only <?php echo $details['stock']; ?> left in stock </blink></p>
      <?php else:  ?>
      <button class="btn btn-success">Available</button>
      <?php endif; ?>
      <p class="card-text">
      <ul style="list-style-type: none">
          
          <li><h5>Color: <button class="btn btn-lg"  style="background-color:<?php echo $details['color']; ?>" ></button> </h5></li>
          <li><h5>Size:  <button class="btn btn-default"> <?php echo strtoupper($details['size']); ?></button> </h5></li>
          <?php echo form_open('index.php/shoppingcart/insert'); ?>
          <li><h5>Quantity: <input type="number" name="data[qty]" value="1" class="col-md-2"  /></h5></li>
          
          <li></li>
          <li></li>
          <li></li>
      </ul>
      </p>
      
  <input type="hidden" name="data[id]" value="<?php echo $details['_id']; ?>" />
  <input type="hidden" name="data[name]" value="<?php echo $details['p_name']; ?>" />
  <input type="hidden" name="data[thumb]" value="<?php echo $details['images']['0']; ?>" />
   <input type="hidden" name="data[price]" value="<?php echo $details['price']['selling']; ?>" />
    <input type="hidden" name="data[vendor]" value="<?php echo $details['vendor_id']; ?>" />
    <input type="hidden" name="available" value="<?php echo $details['stock']; ?>" />
   
    <input type="submit" name="sub1" class="btn btn-primary" value="Add to Cart">
    
    <input type="submit" class="btn btn-primary" value="Buy Now">
    
</form>
  </div>
        </div>
    </div>
    
</div>
    

