 <div class="row">
     <div class="col-md-3" >
                        <div class="card" id="myScrollspy" style="border: 0;">
                    <div class="card-header-tabs">
                        
                        <ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link active" data-toggle="tab" href="#home">Color</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="tab" href="#menu1">Size</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="tab" href="#menu2">Type</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="tab" href="#menu3">Price Range</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="tab" href="#menu5">Pattern</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="tab" href="#menu4">Brand</a>
    </li>
  </ul>
                    </div>
                    <?php echo form_open('index.php/shop/filter') ?>
                    <div class="card-body">
                        
                        <div class="tab-content">
 <div id="home" class="container tab-pane active"><br>
      <h3>Select Color</h3>
      <div class="row">
          <input type="color" name="color" value="#ffffff" class="form-control" />
      </div>
          </div>
    <div id="menu1" class="container tab-pane fade"><br>
      <h3>Select Size</h3>
     
       <select name="size" class="form-control">
           <option  selected="selected">----All----</option>
                <option value="xl">XL</option>
                <option value="l">L</option>
                <option value="m">M</option>
                <option value="s">S</option>
                <?php for($i=10; $i<=40;$i=$i+2): ?>
                <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                <?php endfor; ?>
               
                            </select>
      
    </div>
    <div id="menu2" class="container tab-pane fade"><br>
      <h3>Type</h3>
      <select id="opt" name="type" class="form-control">
           <option selected="selected">----All----</option>
                <?php foreach($type as $r): ?>
                
                <option id="cat" value="<?php echo $r['id']; ?>"><?php echo $r['c_name']; ?></option>
               
                <?php endforeach; ?>
            </select>
    </div>
    <div id="menu3" class="container tab-pane fade"><br>
      <h3>Price Range</h3>
      <select name="price[selling]" class="form-control">
           <option selected="selected">----All----</option>
          <?php for($i=399; $i<=5999;$i=$i+500): ?>
                 <?php $j=$i+500; ?> 
                <option value="<?php echo $i; ?>"><?php echo "$i-$j" ; ?></option>
                <?php endfor; ?>
      </select>
    </div>
    <div id="menu4" class="container tab-pane fade"><br>
      <h3>Select Brand</h3>
      <select id="opt" name="brand" class="form-control">
           <option selected="selected">----All----</option>
                <?php foreach($brand as $ro): ?>
                
                <option id="cat" value="<?php echo $ro['id']; ?>"><img src="<?php echo base_url(); ?>assets/catlog_media/<?php echo $ro['b_logo']; ?>" height="15" width="15"><?php echo $ro['b_name']; ?></option>
               
                <?php endforeach; ?>
            </select>
    </div> 
    <div id="menu5" class="container tab-pane fade"><br>
      <h3>Select Pattern</h3>
      <select name="pattern" class="form-control">
                <option selected="selected">----All----</option>
                <?php foreach($pattern as $p): ?>
                
                <option id="cat" value="<?php echo $p['id']; ?>"><?php echo $p['pattern_name']; ?></option>
               
                <?php endforeach; ?>
            </select>
            
    </div>                         
</div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-success">Apply Filter</button>
                    </form>
                    </div>
                </div>
                    </div>

<div class="col-md-9">
<?php if($this->session->flashdata('err')): ?>
<script type="text/javascript">
    alert("<?php $this->session->flashdata('err') ?>")
</script>
<?php endif; ?>
<div class="row">
<?php foreach ($details as $key) : ?>
    
    <?php
    
    $discount= round((($key['price']['marked']-$key['price']['selling'])/$key['price']['marked'])*100,0);
    
    ?>

<div class="col-sm-4">
    <div class="card" >
        <img class="card-img-top" src="<?php echo base_url(); ?>assets/catlog_media/<?php echo $key['images']['0'];  ?>" height="280" width="240"/>
  <div class="card-body">
      <h6 class="card-title"><a href="<?php echo base_url('index.php/shop/product'); ?>/<?php echo $key['_id'] ?>" ><?php echo $key['p_name']; ?></a> </h6>
      <p class="card-text"><h6> <i class="fa fa-rupee"></i> <?php echo $key['price']['selling'] ?></h6><p class="card-text" align="right"><span class="badge badge-danger"><?php echo $discount ?>% off</span><br><i class="fa fa-rupee"></i><del><?php echo $key['price']['marked'] ?></del></p></p>
  <?php echo form_open('index.php/shoppingcart/insert'); ?>
  <input type="hidden" name="data[id]" value="<?php echo $key['_id']; ?>" />
  <input type="hidden" name="data[name]" value="<?php echo $key['p_name']; ?>" />
  <input type="hidden" name="data[thumb]" value="<?php echo $key['images']['0']; ?>" />
   <input type="hidden" name="data[price]" value="<?php echo $key['price']['selling']; ?>" />
    <input type="hidden" name="data[vendor]" value="<?php echo $key['vendor_id']; ?>" />
    <input type="hidden" name="data[qty]" value="1" />
     <input type="hidden" name="available" value="<?php echo $key['stock']; ?>" />
      
    <input type="submit" name="sub1" class="btn btn-primary" value="Add to Cart">
    
    <input type="submit" name="sub2" class="btn btn-primary" value="Buy Now">
    
    
    
</form>
    
  </div>
</div>
</div>



<?php endforeach; ?>
    <?php include ('compare.php'); ?>
</div>
</div>
</div>
    




