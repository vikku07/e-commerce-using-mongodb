<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-sm-8">
                <ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link active" data-toggle="tab" href="#home">My Profile</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" data-toggle="tab" href="#menu1">My Orders (<?php echo count($order) ?>)</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" data-toggle="tab" href="#menu2">Notifications</a>
  </li>
</ul>

<!-- Tab panes -->
<br>
<div class="tab-content">
    <div class="tab-pane container active" id="home">
        <table border='1'>
            <tr>
                <td><strong>UserName:</strong></td>
                <td><?php echo $userdetail['0']['username'] ?></td>
            </tr>
            <tr>
                <td><strong>Address:</strong></td>
                <td><?php if(isset($userdetail['0']['address'])){
                    echo $userdetail['0']['address'];
                }else{
                    echo '<p class="text-warning">NA</p>';
                } ?></td>
            </tr>
            <tr>
                <td><strong>Moblie No:</strong></td>
                <td><?php if(isset($userdetail['0']['address'])){
                    echo $userdetail['0']['phone'];
                }else{
                    echo '<p class="text-warning">NA</p>';
                } ?></td>
            </tr>
        </table>
    </div>
    <div class="tab-pane container fade" id="menu1">
        <?php foreach($order as $ord): ?>
        <div class="card">
            <div class="card-header">
                <?php echo $ord['pinfo'] ?>
            </div>
            <div class="card-body">
                <h5>Status</h5>
                <hr>
                <div class="progress" style="height:30px">
    <div class="progress-bar bg-success" style="width:20%">
        Placed <i class="fa fa-check"></i>
    </div>
    
      
    </div>                
  
                <br>
                <h5>Address</h5> 
                <hr>
                <?php echo $ord['address'] ?>
                
            </div>
        </div>
        
         

        
        <?php endforeach ; ?>
    </div>
  <div class="tab-pane container fade" id="menu2">...</div>
</div>
            </div>
            <div class="col-sm-4">
                
                    
                        <i class="fa fa-5x fa-user-circle"></i>
                    
                </div>
            </div>
            </div>
        </div>
    </div>
</div>