<div class="jumbotron" >
    <h1 class="text-primary">Check Out <i class="fa fa-arrow-circle-right"></i> </h1>
</div> 
<div class="row">
                <div class="col-md-2"></div>  
                <div class="col-md-8">
                	<span="text-center">* All feilds are required</span>
                    <form method="post" id="booking_car_detailes" enctype="multipart/form-data" action="<?php base_url()?>Billing/check">                                                                  
                        <div class="form-group">
                            <input type="hidden" name="p_id" value="<?php echo $p_id; ?>" />
                    <input type="hidden" name="p_qty" value="<?php echo $p_qty; ?>" />
                            <input type="text"  name="payble_amount" value="<?php echo $price ?>" id="payble_amount" class="form-control" placeholder="Enter Payble Amount" readonly/>
                        </div>
                        <div class="form-group">
                            <input type="text" name="product_info" value="<?php echo $p_name ?>" id="product_info" class="form-control"  Placehosder="Product info" readonly/>
                        </div>
                       <div class="form-group">                      
                           <input type="text"  name="customer_name" id="customer_name" class="form-control" placeholder="Full Name (Only alphabets)" required/>
                        </div>
                        <div class="form-group">                                   
                            <input type="number"  name="mobile_number" id="mobile_number" class="form-control" placeholder="Mobile Number(10 digits)" required/>
                        </div>
                        <div class="form-group">                                   
                            <input type="email"  name="customer_email" id="customer_email" class="form-control" placeholder="Email" required />
                        </div>
                        <div class="form-group">
                            <textarea class="form-control" name="customer_address" id="customer_address" placeholder="Address" required></textarea>
                        </div>
                        <div class="form-group text-right">
                          <button type="submit" class="btn btn-primary">Submit</button>
                          <button class="btn btn-default"  data-dismiss="modal" >Cancel</button>
                        </div>
                    </form>                 
                </div>
                <div class="col-md-2"></div>
            </div>