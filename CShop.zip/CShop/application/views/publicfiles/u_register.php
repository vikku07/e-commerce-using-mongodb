<div class="jumbotron">
    <h1 class="text-primary"> <i class="fa fa-user-secret"></i> Authenticate<h1>
</div>
<?php if( $this->session->flashdata('scs')): ?>
<strong class="text-success"><?php echo $this->session->flashdata('scs'); ?></strong>
<?php endif; ?>
<?php if( $this->session->flashdata('fmsg')): ?>
<?php echo $this->session->flashdata('fmsg'); ?>
<?php endif; ?>
<strong class="text-danger"><?php echo validation_errors(); ?></strong>
<div class="row">
    <div class="col-md-6" >
        <div class="form-group">
            <div class="card" >
                <div class="card-header">Sign Up</div>
                <div class="card-body">
            <?php echo form_open('index.php/user/register'); ?>
            <input type="email" class="form-control" placeholder="Enter Email " name="username" />
            <br>
            <input type="password" class="form-control" placeholder="Enter Password " name="password" />
            <br>
            <input type="submit" value="Sign Up Now" class=" btn btn-success" />
            <button type="button" class="btn btn-primary" ><i class="fa fa-facebook-official"></i> SignUp Using Facebook</button>
            <button type="button" class="btn btn-danger" > <i class="fa fa-google-plus-official"></i> SignUp Using Google +</button>
                </form>
                </div>  
    </div>
        </div>
    </div>
    <div class="col-md-6" >
        <div class="form-group">
            <div class="card" >
                <div class="card-header">Login</div>
                <div class="card-body">
            <?php echo form_open('index.php/user/login'); ?>
            <input type="email" class="form-control" placeholder="Enter Email " name="username" />
            <br>
            <input type="password" class="form-control" placeholder="Enter Password " name="password" />
            <br>
            <input type="submit" value="Login Now" class="btn btn-success" />
            <button type="button" class="btn btn-primary" ><i class="fa fa-facebook-official"></i> Login Using Facebook</button>
            <button type="button" class="btn btn-danger" > <i class="fa fa-google-plus-official"></i> Login Using Google +</button>
                </form>
                </div>  
    </div>
        </div>
    </div>
</div>
