<div class="jumbotron">
    <h1 class="text-primary"><i class="fa fa-archive"></i> Manage Inventory </h1>
</div>
<?php if($this->session->flashdata('dmsg')){
    echo $this->session->flashdata('dmsg');
} ?>

<table class="table table-bordered">
    <thead>
      <tr>
        <th>Product Name</th>
        <th>Vendor</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
        <?php foreach ($products as $key): ?>
      <tr>
        <td><?php echo $key['p_name'] ?></td>
        <td><?php echo $key['vendor_id'] ?></td>
        <td><a href="<?php echo base_url('index.php/admin/removeproduct/'.$key['_id']); ?>" class="btn btn-danger" id="delete" ><i class="fa fa-remove"></i></a>
        <a href="<?php echo base_url('index.php/admin/updateproduct/'.$key['_id']); ?>" class="btn btn-primary" ><i class="fa fa-edit"></i></a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
<script>
