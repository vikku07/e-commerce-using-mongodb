<legend>Add Brand</legend>
<?php if($this->session->flashdata('s_msg')){
    echo $this->session->flashdata('s_msg');
} ?>

<div class="col-sm-6">
    <?php echo form_open('index.php/admin/addbrand'); ?>
        <div class="form-group">
            
            
        <label for="staticEmail" class="col-sm-4 col-form-label">
            Brand Name:
        </label>
        <input type="text" name="b_name" required class="form-control"/>
        
        
        <label for="staticEmail" class="col-sm-4 col-form-label">
            Brand Image:
        </label>
        <div class="custom-file">
            <input type="file" name="b_logo" class="custom-file-input" id="inputGroupFile02" required>
        <label class="custom-file-label" for="inputGroupFile02">Choose file</label>
      </div>
        <label for="staticEmail" class="col-sm-4 col-form-label">
            <br>
        </label>
        <input type="submit" name="submit" value="Add Brand" class="btn btn-success" />
         <input type="reset" name="restet" class="btn btn-danger" />
        
        </div>
    </form>
</div>