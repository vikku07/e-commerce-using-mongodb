
<script type="text/javascript">
$(document).ready(function(){
    var maxField = 50; 
    var addButton = $('#add_button'); 
    var wrapper = $('.field_wrapper'); 
    var fieldHTML = '<div><input type="text" class="form-control" name="adtnl_info[]" value=""><a href="javascript:void(0);" id="remove_button" class="btn btn-danger">Remove</a></div><br>';
    var x = 1; 
    
  
    $(addButton).click(function(){
        
        if(x < maxField){ 
            x++; 
            $(wrapper).append(fieldHTML); 
        }
    });
    
    
    $(wrapper).on('click', '#remove_button', function(e){
        e.preventDefault();
        $(this).parent('div').remove(); 
        x--; 
    });
});
</script>
<center>     
<div class="card">
    <div class="card-body">
    <legend>Add Product</legend>
    <?php if($this->session->flashdata('s_msg')){ 
        echo $this->session->flashdata('s_msg');
    }
?>
     
    <div id="1" class="col-sm-6">
    <?php echo form_open_multipart('index.php/admin/addproduct'); ?>
        <div class="form-group">
            <label for="staticEmail" class="col-sm-4 col-form-label">
            Select For:</label>
            <select id="g_cat" name="for" class="form-control">
                <option value="Men">Men</option>
                <option value="Women">Women</option>
                <option value="Kids">Kids</option>
            </select>
            <label for="staticEmail" class="col-sm-4 col-form-label">
            Select Category:</label>
            <select id="p_for" name="g_cat" class="form-control">
                <option value="tw">Top wear</option>
                <option value="bw">Bottom wear</option>
                
            </select>
            <label for="staticEmail" class="col-sm-4 col-form-label">
            Select season:</label>
            <select id="p_for" name="p_season" class="form-control">
                <option value="tw">Winter</option>
                <option value="bw">Summer</option>
                <option value="rain">Rain</option>
                
            </select>
            <label for="staticEmail" class="col-sm-4 col-form-label">
            Select Type:</label>
            <select id="type" name="cat" class="form-control">
               <?php foreach($type as $r): ?>
                
                <option id="cat" value="<?php echo $r['id']; ?>"><?php echo $r['c_name']; ?></option>
               
                <?php endforeach; ?>
            </select>
            
            <div id="result">
                
            </div>
            <label for="staticEmail" class="col-sm-4 col-form-label">
            Select Brand:</label>
            <select id="opt" name="brand" class="form-control">
                <?php foreach($brand as $ro): ?>
                
                <option id="cat" value="<?php echo $ro['id']; ?>"><img src="<?php echo base_url(); ?>assets/catlog_media/<?php echo $ro['b_logo']; ?>" height="15" width="15"><?php echo $ro['b_name']; ?></option>
               
                <?php endforeach; ?>
            </select>
            <label for="staticEmail" class="col-sm-4 col-form-label">
            Select Type:</label>
            <select name="pattern" class="form-control">
                 <?php foreach($pattern as $p): ?>
                
                <option id="cat" value="<?php echo $p['id']; ?>"><?php echo $p['pattern_name']; ?></option>
               
                <?php endforeach; ?>
            </select>
            <label for="staticEmail" class="col-sm-4 col-form-label">
            Select Size:</label>
            <select name="size" class="form-control">
                <option value="xl">XL</option>
                <option value="l">L</option>
                <option value="m">M</option>
                <option value="s">S</option>
                <?php for($i=10; $i<=40;$i=$i+2): ?>
                <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                <?php endfor; ?>
               
                            </select>
            
            <label for="staticEmail" class="col-sm-4 col-form-label">
            Stock:
        </label>
            <input type="number" name="stock" required class="form-control"/>

        <label for="staticEmail" class="col-sm-4 col-form-label">
            Product Name:
        </label>
        <input type="text" name="p_name" required class="form-control"/>
        
        <label for="staticEmail" class="col-sm-4 col-form-label">
            Product Discription:
        </label>
        <textarea class="ckeditor" name="p_desc"></textarea>
        <label for="staticEmail" class="col-sm-4 col-form-label">
            Marked Price:
        </label>
        <input type="number" step="0.01" name="price[marked]" required class="form-control"/>
        <label for="staticEmail" class="col-sm-4 col-form-label">
            Selling Price:
        </label>
        <input type="number" step="0.01" name="price[selling]" required class="form-control"/>
        
        <label for="staticEmail" class="col-sm-4 col-form-label">
            Select Multiple Images Of Product:
        </label>
        <input type="file" name="images[]" multiple="multiple" class="form-control"  />
       
        <br>
        <input type="color" name="color" class="form-control" />
        
        <br>
        <div class="field_wrapper">
    <div>
        
        <a href="javascript:void(0);" id="add_button"  class="btn btn-success">Add Additional information </a>
        
    </div>
            <br>
    
</div>
        <label for="staticEmail" class="col-sm-4 col-form-label">
            <br>
            <input type="hidden" name="vendor_id" value="<?php echo $vendor_id ?>" /> 
        </label>
        <input type="submit" name="submit" value="Add Product" class="btn btn-success" />
         <input type="reset" name="restet" class="btn btn-danger" />
        
        </div>
    </form>
</div>

</div>
</center>
