<center>
    <div class="col-md-4">
    <div class="card">
        <div class="card-header">Add Vendor</div>
        <div class="card-body">
            <?php echo form_open('index.php/admin/addvendor'); ?>
            <div class="form-group">
                <input type="text" name="name" placeholder="Enter Vendor Name" class="form-control" />
                <br>
                 <input type="email" name="username" placeholder="Enter Vendor's Email Address" class="form-control" />
                 <br>
                 <input type="number" name="mobile" placeholder="Enter Vendor's Mobile Number" class="form-control" />
                 <br>
                 <textarea class="form-control" name="address" placeholder="Enter Vendor's Address" ></textarea>
                 <input type="hidden" name="password" value="<?php echo mt_rand(100000, 999999); ?>" />
                 <input type="hidden" name="joindate" value="<?php echo date('RFC1123'); ?>" />
                 <input type="hidden" name="type" value="vendor" />
                 <input type="hidden" name="status" value="verified" />
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-primary" >Add</button>
            <button type="Reset" class="btn btn-danger" >Reset</button>
        </form>
        </div>
    </div>
    </div>
</center>