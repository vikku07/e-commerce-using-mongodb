<div class="jumbotron">
    <h1 class="text-primary"><i class="fa fa-archive"></i> Manage Orders </h1>
</div>
<?php if($this->session->flashdata('dmsg')){
    echo $this->session->flashdata('dmsg');
} ?>

<table class="table table-bordered">
    <thead>
      <tr>
        <th>Product Name</th>
       
         <th>Order Date</th>
         
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
        <?php foreach ($products as $key): ?>
      <tr>
        <td><?php echo $key['pinfo'] ?></td>
        
        <td><?php if($key['date'] ):?>
        <?php echo $key['date'] ?>
            <?php         endif; ?> 
        </td>
        
        <td>
        <a href="#" class="btn btn-primary" >Dispatch</i></a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
<script>
