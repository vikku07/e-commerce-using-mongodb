
    
      

    <legend>Add Category</legend>
    <?php if($this->session->flashdata('s_msg')){ 
        echo $this->session->flashdata('s_msg');
    }
?>
     
    <div class="col-sm-6">
    <?php echo form_open('index.php/admin/addcategory'); ?>
        <div class="form-group">
            
            
            <br>
            <div id="c">
            
        <label for="staticEmail" class="col-sm-4 col-form-label">
            Category Name:
        </label>
        <input type="text" name="c_name" required class="form-control"/>
        
        <label for="staticEmail" class="col-sm-4 col-form-label">
            Category Discription:
        </label>
        <textarea name="c_desc" class="form-control" rows="10" required></textarea>
        
        <label for="staticEmail" class="col-sm-4 col-form-label">
            Category Image:
        </label>
        <div class="custom-file">
            <input type="file" name="c_img" class="custom-file-input" id="inputGroupFile02" >
        <label class="custom-file-label" for="inputGroupFile02">Choose file</label>
      </div>
        <label for="staticEmail" class="col-sm-4 col-form-label">
            <br>
        </label>
        <input type="submit" name="submit" value="Add Category" class="btn btn-success" />
         <input type="reset" name="restet" class="btn btn-danger" />
        
        </div>
    </form>
</div>
    