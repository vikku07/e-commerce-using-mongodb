<html>
        <head>
                <title>Admin Login</title>
                <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/assets/css/bootstrap.css">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/assets/css/fontawsome.css">
                <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/jquery.js"></script>
                <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/popper.js"></script>
                <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/bootstrap.js"></script>
        </head>
        <body style="background-color:navy; ">
            <br>
        <center>
            <div class="col-sm-5">
            <div class="container">
            <div class="card">
                <div class="card-header">Admin Login</div>
            <div class="form-group">
            <?php if($this->session->flashdata('fmsg')) {
              echo $this->session->flashdata('fmsg') ;
            }?>

                <form action="<?php echo base_url(); ?>index.php/admin/check_login" method="post">
                    <label>Username:</label>
                    <input type="text" name="username" placeholder="Enter username" class="form-control col-6" required>
          <label>Password:</label>
          <input type="password" name="password" placeholder="Enter password" class="form-control  col-6" required>
          <br>
           <a href="<?php echo base_url(); ?>"   class="btn btn-primary btn-lg "><i class="fa fa-arrow-circle-left"> Visit Website </i></a>
          <button type="submit"   class="btn btn-success btn-lg "> Login <i class="fa fa-arrow-circle-right"></i></button>
          

        </form>

            </div>
            </div>
            </div>
            </div>
        </center>

        </body>
        </html>
