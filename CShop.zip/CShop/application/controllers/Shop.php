<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Shop extends MY_Controller {

	public function __construct()
{
parent::__construct();


$this->load->model('publicmodel','pm');
$this->load->model('usermodel','um');
$this->load->library('cart');
}
public function array_most_common($input)
{
  $counted = array_count_values($input);
  arsort($counted);
  return(key($counted));	
}
public function recommendationEngine(){
    
    $user_id= $this->session->userdata('user_id');
    if($user_id){
        $data= $this->um->getPreferences($user_id);
        foreach($data as $d){
            $parry=$d['preferences'];
            for($i=0;$i<count($parry);$i++){
                $p_id=$parry[$i];
                $mydata[]= $this->um->productById($p_id);
            }
    }
    foreach($mydata as $m){
        
        foreach ($m as $k){
            $brandar[]=$k['brand'];
            $catar[]=$k['cat'];
            $patternar[]=$k['pattern'];
            $forar[]=$k['for'];
            $pricear[]=$k['price']['selling'];
            
        }
    }
  
   $brand= $this->array_most_common($brandar);
   $for= $this->array_most_common($forar);
   $pattern= $this->array_most_common($patternar);
   $cat =$this->array_most_common($catar);
   $price =$this->array_most_common($pricear);
   $recm=array(
       'brand'=> strval($brand),
       'for'=>strval($for),
       'pattern'=>strval($pattern),
       'cat'=>strval($cat),
       
       
       );
       return($recm);
  
    
    }
   
}

public function index(){
$this->load->library('pagination');
$recm= $this->recommendationEngine();
$head['recm']= $this->um->recmd($recm);


$config['base_url'] = base_url();
$config['total_rows'] = 10;
$config['per_page'] = 3;

$this->pagination->initialize($config);
 

    $head['title']='Home';
    $data['details']= $this->pm->allProduct();
   
    $data['brand']=$this->pm->getBrand();
    $data['type']=$this->pm->getType();
    $data['pattern']= $this->pm->getPattern();
    $this->load->view('publictemplate/header',$head);
    $this->load->view('publicfiles/home',$data);
    
}

public function productByGender(){
    $recm= $this->recommendationEngine();
$head['recm']= $this->um->recmd($recm);
    $gender= $_GET['c'];
    $head['title']=$gender;
    $data['details']= $this->pm->productbygender($gender);
    $data['brand']=$this->pm->getBrand();
    $data['type']=$this->pm->getType();
    $this->load->view('publictemplate/header',$head);
    $this->load->view('publicfiles/home',$data);
    
}

public function product(){
    $recm= $this->recommendationEngine();
$head['recm']= $this->um->recmd($recm);
    $id= $this->uri->segment('3');
    
    $data['details']= $this->pm->productById($id);
    //print_r($data['details']['images']);
    //exit();
    $cat_id=$data['details']['cat'];
    $data['type']=$this->pm->getcategoryById($cat_id);
    
    if($this->session->userdata('user_id')){
        $user_id=$this->session->userdata('user_id');
        $p_id=$id;
        $this->um->pushUserData($user_id,$p_id);
    }
    
    $head['title']=$data['details']['p_name'];
    $this->load->view('publictemplate/header',$head);
    $this->load->view('publicfiles/product',$data);
}
public function filter(){
    $color=$this->input->post('color');
    $size=$this->input->post('size');
    $brand=$this->input->post('brand');
    $type=$this->input->post('type');
    $pattern=$this->input->post('pattern');
    $filter=array();
    if($size!="----All----"){
        $filter['size']=$size;
    }
    if($brand!="----All----"){
        $filter['brand']=$brand;
    }
    if($type!="----All----"){
        $filter['cat']=$type;
    }
    if($pattern!="----All----"){
        $filter['pattern']=$pattern;
    }
    $head['title']='Filter';
    $data['details']= $this->pm->filterProduct($filter);
   
    $data['brand']=$this->pm->getBrand();
    $data['type']=$this->pm->getType();
    $data['pattern']= $this->pm->getPattern();
    $this->load->view('publictemplate/header',$head);
    $this->load->view('publicfiles/home',$data);
    
}
public function search(){
    $recm= $this->recommendationEngine();
    $head['recm']= $this->um->recmd($recm);
    $s= $this->input->post('search');
    $data['details']= $this->pm->productByName($s);
    //print_r($data['details']['images']);
    //exit();
    $head['title']=$data['details']['p_name'];
    $this->load->view('publictemplate/header',$head);
    $this->load->view('publicfiles/product',$data);
}

public function cartInsert(){
    
    $this->cart-insert($data);
    
}





}