<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends MY_Controller {

	public function __construct()
{
parent::__construct();


$this->load->model('usermodel','um');
$this->load->library('user_agent');

        


}

public function register(){
    if($this->session->userdata('user_id')){
         return redirect('index.php/shop');
    }
    else{
    $this->form_validation->set_rules('username', 'Username', 'required|[users.username]');
    $this->form_validation->set_rules('username', 'Username', 'required');
    if ($this->form_validation->run() == FALSE)
                {
                         $this->load->view('publictemplate/header');
                         $this->load->view('publicfiles/u_register');
                }else{
    $data= $this->input->post();
    unset($data['submit']);
    if($this->um->register($data)){
        
        $this->session->set_flashdata('scs','Account created successfully');
        return redirect($_SERVER['HTTP_REFERER']);
        
        
    }
    else{
        $this->session->set_flashdata('frmerr','Username already exist');
        return redirect($_SERVER['HTTP_REFERER']);
        
    }
                }
    
    }
}
public function login(){
    $uname=$this->input->post('username');
		$pwd=$this->input->post('password');
		$res=$this->mongo_db->where(array('username'=>$uname,'password'=>$pwd))->find_one('users');
		if( $res['username']==$uname && $res['password']==$pwd){
			$this->session->set_userdata(array('user_id'=>$res['_id'],'username'=>$res['username']));
                         return redirect($_SERVER['HTTP_REFERER']);
			
		}
		else{

			$this->session->set_flashdata('fmsg', '<div class="alert alert-dismissible alert-danger">
  <button type="button" class="close" data-dismiss="alert">&times;</button> <b>Invalid Credentials </b>
</div>');
			return redirect($_SERVER['HTTP_REFERER']);
		}
}
public function profile(){
    if($this->session->userdata('user_id')){
        $user_id=$this->session->userdata('user_id');
        $head['title']="My Profille";
        $head['recm']=array();
        $data['userdetail']=$this->um->userDetail($user_id);
        $data['order']= $this->um->userOrder($user_id);
        //print_r($data);
        //exit();
        $this->load->view('publictemplate/header',$head);
        $this->load->view('publicfiles/profile',$data);
    }
}

public function logout(){
		$this->session->unset_userdata('user_id');
		 return redirect($_SERVER['HTTP_REFERER']);
	}

}