<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Status extends My_Controller {
public function __construct() {
        parent::__construct();
        $this->load->helper('url');      
    }
public function index() {
       $status = $this->input->post('status');
      if (empty($status)) {
            redirect('index.php/Biling');
        }
       
        $firstname = $this->input->post('firstname');
        $p_id = $this->input->post('p_id');
        $qty = $this->input->post('p_qty');
        $amount = $this->input->post('amount');
        $txnid = $this->input->post('txnid');
        $posted_hash = $this->input->post('hash');
        $key = $this->input->post('key');
        $productinfo = $this->input->post('productinfo');
        $email = $this->input->post('email');
        $addrs = $this->input->post('address1');
        $salt = "dxmk9SZZ9y"; 
        $add = $this->input->post('additionalCharges');
        
        $phone = $this->input->post('phone');
        $order=array(
            'name'=>$firstname,
            'p_id'=> $p_id,
            'qty'=>$qty,
            'txnid'=>$txnid,
            'email'=>$email,
            'address'=>$addrs,
            'phone'=>$phone
            
            );
            
        If (isset($add)) {
            $additionalCharges = $this->input->post('additionalCharges');
            $retHashSeq = $additionalCharges . '|' . $salt . '|' . $status . '|||||||||||' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
        } else {
            $retHashSeq = $salt . '|' . $status . '|||||||||||' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
        }
         $data['hash'] = hash("sha512", $retHashSeq);
          $data['amount'] = $amount;
          $data['p_id'] = $p_id;
          $data['email'] = $email;
          $data['phone'] = $phone;
          $data['qty'] = $qty;
          $data['p_name'] = $productinfo;
          $data['txnid'] = $txnid;
          $data['address']=$addrs;
          $data['posted_hash'] = $posted_hash;
          $data['date']= date(DATE_RFC2822);
          $data['status'] = $status;
          if($status == 'success'){
              $order= $this->session->userdata('order');
              $order['status']="success";
              $this->session->unset_userdata('order');
              
             
              $this->load->model('adminmodel');
              $this->adminmodel->insertorder($order);
              $this->load->view('publictemplate/header');
              $this->load->view('publicfiles/success', $data);
              
              
         }
         else{
             $this->session->unset_userdata('order');
             $this->load->view('publictemplate/header');
              $this->load->view('publicfiles/fail', $data); 
         }
     
    }
 
    
   }