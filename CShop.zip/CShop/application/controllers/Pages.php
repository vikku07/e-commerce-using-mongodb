<?php
class Pages extends MY_Controller {

        public function view($page = 'home')
        {
        	if ( ! file_exists(APPPATH.'views/adminpages/'.$page.'.php'))
        {
                // Whoops, we don't have a page for that!
                show_404();
        }

        $data['title'] = ucfirst($page); // Capitalize the first letter

        $this->load->view('admintemplate/header', $data);
        $this->load->view('adminpages/'.$page, $data);
        $this->load->view('admintemplate/footer', $data);
        }
}