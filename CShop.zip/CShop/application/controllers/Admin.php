<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends MY_Controller {

	public function __construct()
{
parent::__construct();




$this->load->model('Adminmodel','am');

}
	public function index()
	{
           $head['title']="Dashboard";
		if($this->session->userdata('admin_active')){
		     $this->load->view('admintemplate/header',$head);
                     $this->load->view('admintemplate/sidebar');
                     $this->load->view('adminpages/dashboard');
                     $this->load->view('admintemplate/footer');
		}
		else{

		return redirect('index.php/admin/login');
		}
	}
	public function login(){
		if($this->session->userdata('admin_active')){
			return redirect('index.php/admin/index');
		}
		else{

		$this->load->view('adminpages/login');
		}
	}
	public function check_login(){

		$uname=$this->input->post('username');
		$pwd=$this->input->post('password');
		$res=$this->mongo_db->where(array('username'=>$uname,'password'=>$pwd))->find_one('admin');
		if( $res['username']==$uname && $res['password']==$pwd){
			$this->session->set_userdata(array('admin_active'=>$res['_id'],'type'=>$res['type']));

			return redirect('index.php/admin/index');
		}
		else{

			$this->session->set_flashdata('fmsg', '<div class="alert alert-dismissible alert-danger">
  <button type="button" class="close" data-dismiss="alert">&times;</button> <b>Invalid Credentials </b>
</div>');
			return redirect('index.php/admin/login');
		}
	



	}

	public function Category(){
                 $head['title']="Add Category";
		if($this->session->userdata('admin_active')){
                    
                    $data['category']= $this->am->getCategory();
                    
                    $this->load->view('admintemplate/header',$head);
                    $this->load->view('adminpages/addcategory',$data);
                    

		}
		else{

		return redirect('index.php/admin/login');
		}
                
                
            



	}
        
        public function addCategory(){
            $data= $this->input->post();
            unset($data['submit']);
            
            
            if($this->am->insertCategory($data)){
                
                $this->session->set_flashdata('s_msg','<div class="alert alert-dismissible alert-success">
  <button type="button" class="close" data-dismiss="alert">&times;</button> <b>Category Added Successfully </b>
</div>');
                return redirect('index.php/admin/category');
            }else{
                $this->session->set_flashdata('e_msg','Failed to add');
                return redirect('index.php/admin/category');
            }
           
                    
        }
        public function getdata(){
            $res=$this->mongo_db->where(array('username' => 'vkas'))->get('admin');
            print_r($res);
        }
        
        public function product(){
            
            $head['title']="Add New Product";
            
            if($this->session->userdata('admin_active')){
                    
                $data['category']= $this->am->getCategory();
                $data['brand']= $this->am->getBrand();
                $data['type']= $this->am->getCategory();
                $data['pattern']= $this->am->getPattern();
                $data['vendor_id']=$this->session->userdata('admin_active');
                    
                    $this->load->view('admintemplate/header',$head);
                    $this->load->view('adminpages/addproduct',$data);

		}
		else{

		return redirect('index.php/admin/login');
		}
            
        }
        
        public function addProduct(){
            
                $config['upload_path']          = './assets/catlog_media/';
                $config['allowed_types']        = 'gif|jpg|png';
                $config['max_size']             = 3000;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;

                $this->load->library('upload', $config);
                $dataInfo = array();
                $files = $_FILES;
                $cpt = count($_FILES['images']['name']);
                for($i=0; $i<$cpt; $i++)
               {           
                 $_FILES['images']['name']= $files['images']['name'][$i];
                 $_FILES['images']['type']= $files['images']['type'][$i];
                 $_FILES['images']['tmp_name']= $files['images']['tmp_name'][$i];
                 $_FILES['images']['error']= $files['images']['error'][$i];
                 $_FILES['images']['size']= $files['images']['size'][$i]; 
                if ( ! $this->upload->do_upload('images'))
                {
                        $error = array('error' => $this->upload->display_errors());

                        print_r($error);
                }
                else
                {
                    $dataInfo[$i] = $this->upload->data('file_name');
                    
                
                      $data= $this->input->post();
                      $data['images']=$dataInfo;
                      unset($data['submit']);
                      
                      
            
            
            
                
               
               } 
               }
                              
               
               if($this->am->insertProduct($data)){
                
                $this->session->set_flashdata('s_msg','<div class="alert alert-dismissible alert-success">
  <button type="button" class="close" data-dismiss="alert">&times;</button> <b>Product Added Successfully </b>
</div>');
                return redirect('index.php/admin/product');
            }else{
                $this->session->set_flashdata('e_msg','Failed to add');
                return redirect('index.php/admin/product');
                
            }  
        }
        public function getCategory() {
            $res= $this->am->getCategory();
            print_r($res);
            
        }
        public function getCategoryById(){
            $category = array();
        $c_name = $this->input->post('c_name');
            $category = $this->am->getCategoryById($c_name);
        
        echo json_encode($category);
        }
        public function brand(){
                 $head['title']="Add Brand";
            
            
		if($this->session->userdata('admin_active')){
		     $this->load->view('admintemplate/header',$head);
                    
                     $this->load->view('adminpages/addbrand');
                     $this->load->view('admintemplate/footer');
		}
		else{

		return redirect('index.php/admin/login');
		}
            
        }
        public function addBrand(){
            
            $data= $this->input->post();
            unset($data['submit']);
            
            
            if($this->am->insertBrand($data)){
                
                $this->session->set_flashdata('s_msg','Added sucessfully');
                return redirect('index.php/admin/brand');
            }else{
                $this->session->set_flashdata('e_msg','Failed to add');
                return redirect('index.php/admin/brand');
            }
            
        }
        
        public function order(){
            $head['title']="Order Management";
            $security_check=$this->session->userdata('admin_active');
            if($security_check){
            $data['products']= $this->am->displayOrders();
            $this->load->view('admintemplate/header',$head);
            $this->load->view('adminpages/order',$data);
            }
            
            
        }
        public function displayProducts(){
         $security_check=$this->session->userdata('admin_active');
$admin_type=$this->session->userdata('type');   
            
    if($security_check){
        if($admin_type=='superadmin'){
        $data['products']= $this->am->products();
        $head['title']="Inventory Management";
        $this->load->view('admintemplate/header',$head);
        $this->load->view('adminpages/inventory',$data);
        
    }else{
        $data['products']=$this->mongo_db->where('vendor_id',$security_check)->get('product');
        $head['title']="Inventory Management";
        $this->load->view('admintemplate/header',$head);
        $this->load->view('adminpages/inventory',$data);
        
    }
    }
    else{
        
        return redirect('index.php/admin');
    }
    
}
public function removeProduct(){
    $id= $this->uri->segment('3');
    $security_check=$this->session->userdata('admin_active');{
        if($security_check){
            $query=$this->mongo_db->where('_id',new MongoId($id))->delete('product');
            if($query){
                $this->session->set_flashdata('dmsg', '<div class="alert alert-dismissible alert-success">
  <button type="button" class="close" data-dismiss="alert">&times;</button> <b>Deleted Successfully ! </b>
</div>');
                return redirect('index.php/admin/displayproducts');
            }
        }
    }
}

public function updateproduct(){
    $id= $this->uri->segment('3');
    $security_check=$this->session->userdata('admin_active');
        if($security_check){
    $data['details']=$this->mongo_db->where('_id',new MongoId($id))->find_one('product');
    $data['category']= $this->am->getCategory();
                $data['brand']= $this->am->getBrand();
                $data['type']= $this->am->getCategory();
                $data['pattern']= $this->am->getPattern();
                $data['vendor_id']=$this->session->userdata('admin_active');
    $head['title']="Inventory Management";
        $this->load->view('admintemplate/header',$head);
        $this->load->view('adminpages/updateproduct',$data);
        }
    else{
            return redirect('index.php/admin/login');
    }
}

public function ExcelReport(){
    $col=$_GET['c'];
     $this->load->library('excel');
        //activate worksheet number 1
        $this->excel->setActiveSheetIndex(0);
        //name the worksheet
        $this->excel->getActiveSheet()->setTitle($col);
 
        
 
        // get all users in array formate
        $data = $this->am->generateexcel($col);
 
        // read data to active sheet
        $this->excel->getActiveSheet()->fromArray($data);
 
        $filename=$col.'.xls'; //save our workbook as this file name
 
        header('Content-Type: application/vnd.ms-excel'); //mime type
 
        header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name
 
        header('Cache-Control: max-age=0'); //no cache
                    
        //save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
        //if you want to save it as.XLSX Excel 2007 format
 
        $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5'); 
 
        //force user to download the Excel file without writing it to server's HD
        $objWriter->save('php://output');
    
    
}
public function vendor(){
    $security_check=$this->session->userdata('admin_active');
    $type=$this->session->userdata('type');
            if($security_check){
                if($type=="superadmin"){
                    $head['title']="Add Vendor";
                    $this->load->view('admintemplate/header',$head);
                    $this->load->view('adminpages/addvendor');
                }else{
                    
                    echo "Sorry ! you are not a super admin";
                }
}
}
public function addVendor(){
    $security_check=$this->session->userdata('admin_active');
    $type=$this->session->userdata('type');
            if($security_check){
                if($type=="superadmin"){
                    $data= $this->input->post();
                    $res= $this->am->addvendor($data);
                    if($res){
                        $this->session->set_flashdata('vsmsg','<div class="alert alert-dismissible alert-success">
  <button type="button" class="close" data-dismiss="alert">&times;</button> <b>Vendor Added Successfully ! </b>
</div>');
                    echo "success";   
                    }
                }
            }else{
                return redirect('index.php/admin');
            }
}
public function updateProd(){
    $security_check=$this->session->userdata('admin_active');
    if($security_check){
        $data= $this->input->post();
        $id=$data['p_id'];
        foreach ($data as $key => $value) {
            if($value=="Select"){
                unset($data[$key]);
            }
        }
         unset($data['submit']);
          unset($data['p_id']);
        if($this->am->updateprod($data,$id)){
            $this->session->set_flashdata('upsmsg','<div class="alert alert-dismissible alert-success">
  <button type="button" class="close" data-dismiss="alert">&times;</button> <b>Product Update Successfully ! </b>
</div>');
             return redirect($_SERVER['HTTP_REFERER']);
        }
    }
}

public function logout(){
		$this->session->unset_userdata('admin_active');
		return redirect('index.php/admin/login');
	}
}
