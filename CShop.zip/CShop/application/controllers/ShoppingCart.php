<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ShoppingCart extends MY_Controller {

	public function __construct()
{
parent::__construct();

$this->load->library('user_agent');
}

public function index(){
    
    $head['title']="Cart";
    
    $this->load->view('publictemplate/header.php',$head);
    $this->load->view('publicfiles/cart');
    
    
}

public function insert(){
    $data= $this->input->post('data');
    //print_r($this->input->post());
    //exit();
    $cartdata = array(
        'id'      => $data['id'],
        'qty'     => $data['qty'],
        'price'   => $data['price'],
        'name'    => $data['name'],
       
);

    if($this->input->post('sub1')=='Add to Cart'){
    $this->cart->insert($cartdata);
    return redirect($_SERVER['HTTP_REFERER']);
   }else{
        $this->cart->insert($cartdata);
    return redirect('index.php/shoppingcart');
   }
   
    
    
    
}



public function remove(){
    $this->cart->remove($this->uri->segment('3'));    
    return redirect('index.php/shoppingcart');
}

public function update(){
    $this->cart->remove();    
    return redirect('index.php/shoppingcart');
}
public  function placeOrder(){
    
    $this->load->view('publictemplate/header.php');
    if($this->session->userdata('user_id')){
        
        echo 'hi';
        
    } else {
        $this->load->view('publicfiles/u_register');
    }
    
    
}
}
?>


