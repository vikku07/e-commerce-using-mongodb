<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Billing extends MY_Controller {
public function __construct() {
        parent::__construct();
        $this->load->helper('url');       
    }
 public function index(){
     $data=$this->input->post();
     
     $this->load->view('publictemplate/header');
    $this->load->view('publicfiles/form1',$data);
 }
 public function check(){
     
     // all values are required
    $amount =  $this->input->post('payble_amount');
    $product_info = $this->input->post('product_info');
    $customer_name = $this->input->post('customer_name');
    $customer_emial = $this->input->post('customer_email');
    $customer_mobile = $this->input->post('mobile_number');
    $customer_address = $this->input->post('customer_address');
    $p_id = $this->input->post('p_id');
    $qty = $this->input->post('p_qty');
    if($this->session->userdata('user_id')){
        $user_id=$this->session->userdata('user_id');
    }else{
        $user_id="";
    }
    
    //payumoney details
    //4012001037141112
    
    
        $MERCHANT_KEY = "gtKFFx"; //change  merchant with yours
        $SALT = "eCwWELxi";  //change salt with yours 
        $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
        //optional udf values 
        $udf1 = '';
        $udf2 = '';
        $udf3 = '';
        $udf4 = '';
        $udf5 = '';
        
         $hashstring = $MERCHANT_KEY . '|' . $txnid . '|' . $amount . '|' . $product_info . '|' . $customer_name . '|' . $customer_emial . '|' . $udf1 . '|' . $udf2 . '|' . $udf3 . '|' . $udf4 . '|' . $udf5 . '||||||' . $SALT;
         $hash = strtolower(hash('sha512', $hashstring));
         
       $success = base_url('index.php/') . 'Status';  
        $fail = base_url('index.php/') . 'Status';
        $cancel = base_url('index.php/') . 'Status';
        
        
         $data['details'] = array(
            'mkey' => $MERCHANT_KEY,
             'p_id'=>$p_id,
             'qty'=>$qty,
             'user_id'=>$user_id,
            'orderstatus'=>'Placed', 
            'tid' => $txnid,
            'hash' => $hash,
            'amount' => $amount,           
            'name' => $customer_name,
            'pinfo' => $product_info,
            'mailid' => $customer_emial,
            'phoneno' => $customer_mobile,
            'address' => $customer_address,
            'action' => "https://test.payu.in", //for live change action  https://secure.payu.in
            'sucess' => $success,
            'failure' => $fail,
            'cancel' => $cancel,
            'date'=> date('Y-m-d H:i:s')    
        );
        $this->session->set_userdata('order',$data['details']);
         $this->load->view('publictemplate/header');
        $this->load->view('publicfiles/confirmation', $data);   
     }
   
    
   }
