<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inventory extends MY_Controller {

	public function __construct()
{
parent::__construct();


$this->load->model('Adminmodel','am');
$security_check= $this->session->userdata('admin_active');
}

public function displayProducts(){
    if($security_check){
        $data['products']= $this->am->productByVendor($security_check);
        $head="Inventory Management";
        $this->load->view('admintemplate/header',$head);
        $this->load->view('adminpages/inventory',$data);
        print_r($data);
    }
    else{
        
        return redirect('index.php/admin');
    }
}

}
?>

