<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Usermodel extends MY_Model{
    
    public function register($data){
        $this->mongo_db->insert('users',$data);
    }
    public function pushUserData($user_id,$p_id){
       $this->mongo_db->where(array('_id'=> new MongoId($user_id)))->addtoset('preferences', $p_id)->update('users');
    }
    public function getPreferences($user_id){
        $query= $this->mongo_db->select(array('preferences'))->where(array('_id'=> new MongoId($user_id)))->get('users');
        return $query;
    }
    public function userDetail($user_id){
        $query= $this->mongo_db->where(array('_id'=> new MongoId($user_id)))->get('users');
        return $query;
    }
    public function productById($p_id){
        $query= $this->mongo_db->select(array('for','cat','size','brand','price','pattern'))->where(array('_id'=> new MongoId($p_id)))->get('product');
        return $query;
    }
    public function recmd($recm){
        if($this->session->userdata('user_id')){
       $query=$this->mongo_db->limit(5)->where($recm)->get('product');
        //$query=$this->mongo_db->get_where('product', array('brand'=>$recm['brand']));
       
        
       return $query;
    }
    
    }
    public function userOrder($user_id){
        $query= $this->mongo_db->where(array('user_id'=> new MongoId($user_id)))->get('orders');
        return $query;
    }
}