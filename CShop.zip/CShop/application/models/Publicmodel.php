<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Publicmodel extends MY_Model{
    
    public function allProduct(){
        $query=$this->mongo_db->get('product');
        return $query;
        
    }
    
    public function productById($id){
      $query= $this->mongo_db->where('_id',new MongoId($id))->find_one('product');
        return $query;
    }
    public function productByName($s){
      $query= $this->mongo_db->where('p_name',$s)->find_one('product');
        return $query;
    }
    public function productByGender($gender){
        
      $query= $this->mongo_db->where('for',$gender)->get('product');
        return $query;
    }
    public function filterProduct($filter){
        
      $query= $this->mongo_db->where($filter)->get('product');
        return $query;
    }
    public function getBrand(){
       $query=$this->db->get('brand');
        return $query->result_array();
    }
     public function getType(){
       $query=$this->db->get('category');
        return $query->result_array();
    }
    public function getPattern(){
       $query=$this->db->get('pattern');
        return $query->result_array();
    }
    public function getCategoryById($cat_id){
        $this->db->select('c_name');
        $this->db->from('category');
        $this->db->where('id',$cat_id);
        $query=$this->db->get();
        return $query->result_array();
    }
    
}

