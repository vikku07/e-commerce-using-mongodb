<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Adminmodel extends MY_Model{
    
    public function insertCategory($data){
        $this->db->insert('category', $data);
    }
    public function insertBrand($data){
        $this->db->insert('brand', $data);
    }
    public function insertProduct($data){
        $this->mongo_db->insert('product', $data);
    }
    public function addVendor($data){
        $this->mongo_db->insert('admin', $data);
    }
    public function insertOrder($data){
        $this->mongo_db->insert('orders', $data);
    }
    
    public function getCategory(){
       $query=$this->db->get('category');
        return $query->result_array();
    }
    public function getPattern(){
       $query=$this->db->get('pattern');
        return $query->result_array();
    }
    public function getBrand(){
       $query=$this->db->get('brand');
        return $query->result_array();
    }
    
    public function getCategoryById($c_name){
        $this->db->select('id','c_name');
        $this->db->from('category');
        $this->db->where('c_name',$c_name);
        $query=$this->db->get();
        return $query->result_array();
    }
    public function products(){
      $query= $this->mongo_db->get('product');
        return $query;
    }
    public function updateprod($data,$id){
      $query= $this->mongo_db->where('_id',new MongoId($id))->set($data)->update('product');
        return $query;
    }
     public function productupdate($data){
      $query= $this->mongo_db->getwhere('_id',new MongoId($id))->update('product');
        return $query;
    }
     public function displayOrders(){
      $query= $this->mongo_db->get('orders');
        return $query;
    }
    public function generateExcel($col){
      $query= $this->mongo_db->get($col);
        return $query;
    }
}


?>